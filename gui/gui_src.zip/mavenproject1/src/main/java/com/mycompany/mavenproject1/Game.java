
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

class Game {
  private Scanner sc;
  private Player player;
  private ArrayList<Engimon> engimonliar;
  private ArrayList<Skill> containerskill;
  private Map map;
  private int turn;
  private int maxLiar;
  private NewJFrame window;
  private int sr;
  private int mr;
  private int ar;

  public Game() {
    sc = new Scanner(System.in);
    turn = 0;
    maxLiar = 10;
    sr = 10;
    mr = 5;
    ar = 15;
  }

  public Player getPlayer(){
    return this.player;
  }
  public Map getMap(){
    return this.map;
  }
  public ArrayList<Engimon> getContainerLiar(){
    return this.engimonliar;
  }

  public void start(){
    intro();
    play();
  }
  
  public void start(NewJFrame other){
      window = other;
      //start();
  }

  private void play() {
    String cmd = "";
    window.updatetext("");
    /* (!cmd.equals("exit") && !player.getIsLose())
    {
      window.updatemap();
      map.printMap();
      System.out.printf("Turn: %d\n", turn+1);
      window.updatetext("> ");
      cmd = window.askdata();
      handleCMD(cmd);
      turn++;
      if(turn%1 == 0){
        if (engimonliar.size()>0){
          moveRandom(turn);
        }
      }
      if(turn%10 == 0){
        spawnRandom();
      }
    }
    if (player.getIsLose()){
      window.updatetext("Sorry mister tp km kalah");
    } else {
      window.updatetext("Terima kasih telah memainkan permainan ini :)");
    }*/
  }
  
  public void exe(String cmd){
      handleCMD(cmd);
      turn++;
      if(turn%mr == 0){
        if (engimonliar.size()>0){
          moveRandom(turn);
        }
      }
      if(turn%sr == 0){
        spawnRandom();
      }
      window.updatemap();
      updateinven();
      if (player.getIsLose()){
          window.popup("Kamu kalah broo silakan restart");
          window.game();
      }
  }
  
  public void updateinven(){
      String data = player.getMyEngimons().printInvenEngimon();
      data += "\n";
      data += player.getMySkillItems().printInvenSkill();
      window.updateinven(data);
  }

  public void intro() {
    window.updatetext("Selamat datang, calon pemain!");
    window.updatetext("Mau new game apa kaga? (new/load)");
    window.updatetext("New/Load ??: ");
    String he = window.askdata("New apa load?");
    if (he.equals("load")){
      window.updatetext("Masukkan nama file: ");
      load(window.askdata("Masukkan nama file"));
    } else if (he.equals("new")){
      init();
    }
  }

  public void init()
  {
    String name;
    window.updatetext("Input name: ");
    name = window.askdata("Masukin nama: ");
    window.updatetext("Hello, "+name);

    /* init semua attr */
    this.engimonliar = new ArrayList<>();

    // init container skills
    this.containerskill = new ArrayList<>();
    initSkills();

    // init player
    Engimon engimonDefault = new Engimon();
    window.updatetext("<< Pilih Engimon >>");
    window.updatetext("[1] Firemon");
    window.updatetext("[2] Watermon");
    window.updatetext("[3] Groundmon");
    window.updatetext("[4] Icemonon");
    window.updatetext("[5] Electricmon");

		int engi = -1;
    do {
			window.updatetext("Mau engimon nomor berapa nih bang: ");
			engi = Integer.parseInt(window.askdata("<< Pilih Engimon >>\n[1] Firemon\n[2] Watermon\n[3] Groundmon\n[4] Icemonon\n[5] Electricmon\n\nMasukin nomor engi:"));
		} while (!(engi > 0 && engi < 6));

		String namaEngi;
		window.updatetext("Cakepp bet dah, kasih nama siapa nih: ");
    namaEngi = window.askdata("Masukin nama engimon:");

		switch (engi)
		{
		case 1:
			engimonDefault = new Firemon(namaEngi, false);
			break;
		case 2:
			engimonDefault = new Watermon(namaEngi, false);
			break;
		case 3:
			engimonDefault = new Groundmon(namaEngi, false);
			break;
		case 4:
			engimonDefault = new Icemon(namaEngi, false);
			break;
		case 5:
			engimonDefault = new Electricmon(namaEngi, false);
			break;
		default:
			break;
		}
		this.player = new Player(name, engimonDefault);
    window.updatetext(player.getActiveEngimon().printInfo());
    initmap();
    spawnRandom();
  }

  private void initmap() {
    map = new Map();
    map.playerInisiasi(player);
    player.getActiveEngimon().move(5,5);
    map.engimonInisiasi(player.getActiveEngimon());
  }

  private void handleCMD(String cmd){
    /* handle cmd */
    int choice,choice2,choice3;
    if (cmd.equals("help")){
      window.updatetext("Daftar Command:");
      window.updatetext("- w/a/s/d - untuk berpindah pada map");
      window.updatetext("- listEngimon - menampilkan daftar engimon saat ini");
      window.updatetext("- listSkill - menampilkan daftar skill item di inventory saat ini");
      window.updatetext("- infoEngimon - menampilkan informasi engimon sesuai pilihan");
      window.updatetext("- replaceSkillEngi - mengganti skill engimon dengan skill baru");
      window.updatetext("- switchActive - mengganti status engimon sesuai pilihan");
      window.updatetext("- useSkill - menggunakan skill yang dimiliki sesuai pilihan");
      window.updatetext("- breeding - mengawinkan engimon berdasarkan dua engimon yang dimiliki sesuai pilihan");
      window.updatetext("- battle - melakukan battle dengan engimon liar yang sedang bersisian dengan player pada map");
      window.updatetext("- removeEngimon - mengeluarkan Engimon dari Inventory");
      window.updatetext("- removeSkill - mengurangi X skill dari Inventory");
      window.updatetext("- changeNameEngimon - mengganti nama Engimon pada Inventory");
      window.updatetext("- interract - berinteraksi dengan active Engimon");
      window.updatetext("- save - menyimpan state permainan saat ini");
    } else if (cmd.equals("w") || cmd.equals("a") || cmd.equals("s") || cmd.equals("d")){
      int deltaX=0, deltaY=0;
      int deltaX2=0, deltaY2=0;
      int bX = player.getX(), bY = player.getY();
      Engimon aktif = player.getActiveEngimon();
      int bX2 = aktif.getX(), bY2 = aktif.getY();
      if (cmd.equals("w")){
        deltaY = -1;
        deltaY2 = 1;
      } else if (cmd.equals("a")){
        deltaX = -1;
        deltaX2 = 1;
      } else if (cmd.equals("s")){
        deltaY = 1;
        deltaY2 = -1;
      } else if (cmd.equals("d")){
        deltaX = 1;
        deltaX2 = -1;
      }
      if (bX+deltaX < map.getXsize() && bX+deltaX >= 0 && bY+deltaY < map.getYsize() && bY+deltaY >= 0){
        try{
          if (map.isAdaEntity(bX+deltaX, bY+deltaY)){
            if (aktif.getX() == bX+deltaX && aktif.getY() == bY+deltaY){
              aktif.setX(bX+deltaX2);
              aktif.setY(bY+deltaY2);
              map.pseudomoveEngimon(bX2, bY2, aktif);
              bX2 = aktif.getX();
              bY2 = aktif.getY();
              player.move(bX+deltaX, bY+deltaY);
              map.pseudomovePlayer(bX, bY, player);
              aktif.setX(bX+deltaX+deltaX2);
              aktif.setY(bY+deltaY+deltaY2);
              map.pseudomoveEngimon(bX2, bY2, aktif);
            }
          } else {
            player.move(bX+deltaX, bY+deltaY);
            map.pseudomovePlayer(bX, bY, player);
            aktif.setX(bX+deltaX+deltaX2);
            aktif.setY(bY+deltaY+deltaY2);
            map.pseudomoveEngimon(bX2, bY2, aktif);
          }
        } catch (Exception e){
          player.move(bX, bY);
          map.pseudomovePlayer(bX, bY, player);
          aktif.setX(bX2);
          aktif.setY(bY2);
          map.pseudomoveEngimon(bX2, bY2, aktif);
          window.updatetext("Mentok brok, cari arah lain");
        }
      }
      window.updatetext("Legend:\n");
        window.updatetext("W/w: Water engimon");
        window.updatetext("I/i: Ice engimon");
        window.updatetext("F/f: Fire engimon");
        window.updatetext("G/g: Ground engimon");
        window.updatetext("E/e: Electric engimon");
        window.updatetext("L/l: Fire/Electric engimon");
        window.updatetext("S/s: Water/Ice engimon");
        window.updatetext("N.n: Water/Ground engimon");
        window.updatetext("P  : Player");
        window.updatetext("X  : Active Engimon\n");
        window.updatetext("hijau : Grassland");
        window.updatetext("biru  : Sea");
        window.updatetext("oren  : tundra\n");
        window.updatetext("turn: "+turn);
    } else if (cmd.equals("listEngimon")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
    } else if (cmd.equals("listSkill")){
      window.updatetext(player.getMySkillItems().printInvenSkill());
    } else if (cmd.equals("replaceSkillEngi")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("\nMau ganti skill siape nih: ");
      choice = Integer.parseInt(window.askdata("Mau ganti skill siape nih:"));
      window.updatetext(player.getMyEngimons().getItem(choice-1).printSkill());
      window.updatetext("\nGanti skill yang mane nih: ");
      window.updatetext(player.getMySkillItems().printInvenSkill());
      choice2 = Integer.parseInt(window.askdata("Ganti skill yang mane nih:"));
      if (player.getMySkillItems().countItem() != 0){
        window.updatetext("Ganti pake yang mana: ");
        choice3 = Integer.parseInt(window.askdata("Ganti pake yang mana:"));
        player.getMyEngimons().getItem(choice2-1).replaceSkill(player.getMyEngimons().getItem(choice-1).skillEngimon.get(choice2-1), player.getMySkillItems().getItem(choice-1));
      }
    } else if (cmd.equals("infoEngimon")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("Mau liat yang mana: ");
      choice = Integer.parseInt(window.askdata());
      window.updatetext(player.getMyEngimons().getItem(choice-1).printInfo());
    } else if (cmd.equals("switchActive")){
      Engimon aktip = player.getActiveEngimon();
      int bX = aktip.getX(), bY = aktip.getY();
      window.updatetext("Current Active Engimon: "+player.getActiveEngimon());
      window.updatetext(player.getActiveEngimon().printInfo());
      window.updatetext("");

      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("\nMau switch sama yang mana: ");
      choice = Integer.parseInt(window.askdata());
      player.switchActiveEngimon(player.getMyEngimons().getItem(choice-1));
      map.removeFromMap(bX, bY);
      player.getActiveEngimon().setX(bX);
      player.getActiveEngimon().setY(bY);
      map.engimonInisiasi(player.getActiveEngimon());
    } else if (cmd.equals("useSkill")){
      window.updatetext(player.getMySkillItems().printInvenSkill());
      if (player.getMySkillItems().countItem() != 0){
        window.updatetext("Mau pake yang mana: ");
        choice = Integer.parseInt(window.askdata());
        window.updatetext(player.getMyEngimons().printInvenEngimon());
        window.updatetext("Pakein ke siapa: ");
        choice2 = Integer.parseInt(window.askdata());
        player.getMyEngimons().getItem(choice2-1).learnSkill(player.getMySkillItems().getItem(choice-1));
      }
    } else if (cmd.equals("breeding")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("Pilih parent 1: ");
      choice = Integer.parseInt(window.askdata());
      window.updatetext("Pilih parent 2: ");
      choice2 = Integer.parseInt(window.askdata());
      player.breeding(player.getMyEngimons().getItem(choice-1), player.getMyEngimons().getItem(choice2-1));
    } else if (cmd.equals("battle")){
      Engimon aktip = player.getActiveEngimon();
      int bX = aktip.getX(), bY = aktip.getY();
      List<Engimon> enemys = this.adjacentEngimon();
      if (!enemys.isEmpty()){
        window.updatetext("<< List Engimon liar dekat kamu >>");
        int i = 0;
        String ask = "";
        for (Engimon e : enemys){
            String aa = "["+(i+1)+"] "+e;
            ask += aa+"\n";
          window.updatetext(aa);
          window.updatetext(e.printInfo());
          window.updatetext("");
          i++;
       }
       window.updatetext("Challenge engimon nomor (0 kalo mau kabur): ");
       choice = Integer.parseInt(window.askdata("Pilih yang mau diajak ribut:\n\n"+ask));
       if (choice == 0){
        window.updatetext("<< Kamu kabur >>");
        return;
       }
       window.updatetext("<< BATTLE BEGIN >>\n");
       window.updatetext(player.getActiveEngimon().printInfo());
       window.updatetext("\n\n -- VERSUS --\n\n");
       window.updatetext(enemys.get(choice-1).printInfo());
       window.updatetext("");
       int result = player.battle(enemys.get(choice-1));
       if (result == 1){
         engimonliar.remove(engimonliar.indexOf(enemys.get(choice-1)));
         map.removeFromMap(enemys.get(choice-1).getX(), enemys.get(choice-1).getY());
       } else {
         if (result == -1){
          map.removeFromMap(bX, bY);
          player.getActiveEngimon().setX(bX);
          player.getActiveEngimon().setY(bY);
          map.engimonInisiasi(player.getActiveEngimon());
         }
       }
      } else {
        window.updatetext("Gaada engimon deket kamu master!");
      }
    } else if (cmd.equals("removeEngimon")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("Mana yang mau dibuang: ");
      choice = Integer.parseInt(window.askdata());
      player.getMyEngimons().removeItem(player.getMyEngimons().getItem(choice-1));
    } else if (cmd.equals("removeSkill")){
      window.updatetext(player.getMySkillItems().printInvenSkill());
      if (player.getMySkillItems().countItem() != 0){
        window.updatetext("Mana yang mau dibuang: ");
        choice = Integer.parseInt(window.askdata());
        if (player.getMySkillItems().getQuantity(player.getMySkillItems().getItem(choice-1)) > 1){
          window.updatetext("Berapa: ");
          choice2 = Integer.parseInt(window.askdata());
          for (int i = 0; i < choice2; i ++){
            player.getMySkillItems().removeItem(player.getMySkillItems().getItem(choice-1));
          }
        } else {
          player.getMySkillItems().removeItem(player.getMySkillItems().getItem(choice-1));
        }
      }
    } else if (cmd.equals("changeNameEngimon")){
      window.updatetext(player.getMyEngimons().printInvenEngimon());
      window.updatetext("Mana yang mau diganti: ");
      choice = Integer.parseInt(window.askdata("Mana yang mau diganti:"));
      window.updatetext("Ganti nama jadi apa: ");
      String newname = window.askdata("Nama baru:");
      player.getMyEngimons().getItem(choice-1).setNamaEngimon(newname);
    } else if (cmd.equals("interract")){
      List<Engimon> adj = this.adjacentEngimon();
      if (adj.isEmpty()){
        player.getActiveEngimon().interract();
      } else {
        Engimon e = adj.get(ThreadLocalRandom.current().nextInt(0, adj.size()));
        e.interract();
      }
    } else if (cmd.equals("save")){
      window.updatetext("Masukkan nama file: ");
      save(window.askdata());
    }
    
  }

  private void moveRandom(int turn) {
    int next[][] = new int[4][2];
    next[0][0] = 0;
    next[0][1] = -1;
    next[1][0] = 0;
    next[1][1] = 1;
    next[2][0] = 1;
    next[2][1] = 0;
    next[3][0] = -1;
    next[3][1] = 0;

    for (int i = 0 ; i < engimonliar.size(); i++){
      Engimon e = engimonliar.get(i);
      if (e.isMati()){
        continue;
      }
      int bX = e.getX(), bY = e.getY();
      int finalX = 0, finalY = 0, choice = 0;

      boolean condition = false;
      String specEng = e.getSpecies();   

      int limit = 0;
      while (!condition){
        limit++;
        if (limit>100){
          break;
        }
        choice = ThreadLocalRandom.current().nextInt(0, next.length);
        finalX = bX+next[choice][0];
        finalY = bY+next[choice][1];
        while (!(finalX < map.getXsize() && finalX >= 0 && finalY < map.getYsize() && finalY >= 0 && !map.isAdaEntity(finalX, finalY))){
          choice = ThreadLocalRandom.current().nextInt(0, next.length);
          finalX = bX+next[choice][0];
          finalY = bY+next[choice][1];
        }
        if(specEng.equals("watermon")){
          condition = map.isSea(finalX, finalY);
        } else if(specEng.equals("watericemon")){
          condition = map.isSea(finalX, finalY) || map.isTundra(finalX, finalY);
        } else if(specEng.equals("watergroundmon")){
          condition = map.isSea(finalX, finalY) ||  map.isGrassLand(finalX, finalY);
        } else if(specEng.equals("icemon")){
          condition = map.isTundra(finalX, finalY);
        } else if(specEng.equals("groundmon")){
          condition = map.isGrassLand(finalX, finalY);
        } else if(specEng.equals("firemon")){
          condition = map.isMountain(finalX, finalY);
        } else if(specEng.equals("fireelectricmon")){
          condition = map.isGrassLand(finalX,finalY) ||  map.isMountain(finalX, finalY);
        } else if(specEng.equals("electricmon")){
          condition = map.isGrassLand(finalX, finalY);
        }
      }
      if (limit>100){
        continue;
      }
      if (turn%ar==0){
        e.addExp(100);
      }
      if (e.isMati()){
        engimonliar.remove(engimonliar.indexOf(e));
        map.removeFromMap(bX, bY);
      } else {
        e.move(finalX, finalY);
        map.pseudomoveEngimon(bX, bY, e);
      }
    }
  }

  private void spawnRandom() {
    if (engimonliar.size() >= maxLiar){
      return;
    }
    List<Engimon> tes = new ArrayList<>();
    Engimon e;
    int x = ThreadLocalRandom.current().nextInt(0, 12);
    int y = ThreadLocalRandom.current().nextInt(0, 10);
    while (map.isAdaEntity(x,y)){
      x = ThreadLocalRandom.current().nextInt(0, 12);
      y = ThreadLocalRandom.current().nextInt(0, 10);
    }
    tes.add(new FireElectricmon(x,y));
    tes.add(new Electricmon(x,y));
    tes.add(new Firemon(x,y));
    tes.add(new Groundmon(x,y));
    tes.add(new Icemon(x,y));
    tes.add(new WaterGroundmon(x,y));
    tes.add(new WaterIcemon(x,y));
    tes.add(new Watermon(x,y));

    e = tes.get(ThreadLocalRandom.current().nextInt(0, 8));
    boolean condition = false;
    String specEng = e.getSpecies();   

    while (!condition){
      x = ThreadLocalRandom.current().nextInt(0, 12);
      y = ThreadLocalRandom.current().nextInt(0, 10);
      while (map.isAdaEntity(x,y)){
        x = ThreadLocalRandom.current().nextInt(0, 12);
        y = ThreadLocalRandom.current().nextInt(0, 10);
      }
      e.setX(x); e.setY(y);
      if(specEng == "watermon"){
        condition = map.isSea(e.getX(), e.getY());
      } else if(specEng == "watericemon"){
        condition = map.isSea(e.getX(), e.getY()) || map.isTundra(e.getX(), e.getY());
      } else if(specEng == "watergroundmon"){
        condition = map.isSea(e.getX(), e.getY()) ||  map.isGrassLand(e.getX(), e.getY());
      } else if(specEng == "icemon"){
        condition = map.isTundra(e.getX(), e.getY());
      } else if(specEng == "groundmon"){
        condition = map.isGrassLand(e.getX(), e.getY());
      } else if(specEng == "firemon"){
        condition = map.isMountain(e.getX(), e.getY());
      } else if(specEng == "fireelectricmon"){
        condition = map.isGrassLand(e.getX(), e.getY()) ||  map.isMountain(e.getX(), e.getY());
      } else if(specEng == "electricmon"){
        condition = map.isGrassLand(e.getX(), e.getY());
      }
    }
    e.setLevel(player.getMaxLevelEngimon());
    engimonliar.add(e);
    map.spawnEngimonLiar(e);
  }
  
  private void initSkills(){
    GameFile skillsfile = new GameFile("Skill.txt"," ");
    List<String[]> skills = skillsfile.read();
    for (String[] arg : skills){
      if (arg.length > 3){
          containerskill.add(new Skill(arg[0],Integer.parseInt(arg[1]),arg[2],arg[3]));
      }
      containerskill.add(new Skill(arg[0],Integer.parseInt(arg[1]),arg[2]));
    }
  }

  private List<Engimon> adjacentEngimon(){
    int x = player.getX(), y = player.getY();
    List<Engimon> out = new ArrayList<>();
    int next[][] = new int[4][2];
    next[0][0] = 0;
    next[0][1] = -1;
    next[1][0] = 0;
    next[1][1] = 1;
    next[2][0] = 1;
    next[2][1] = 0;
    next[3][0] = -1;
    next[3][1] = 0;

    for (Engimon e : engimonliar){
      if (e.isMati()){
        continue;
      }
      for (int[] delta : next){
        int dx = x+delta[0], dy = y+delta[1];
        if (e.getX() == dx && e.getY() == dy){
          out.add(e);
          break;
        }
      }
    }
    return out;
  }

  private void save(String filename) {
    /* save Game state */
    GameFile a = new GameFile(filename, " ");
    List<String[]> out = new ArrayList<>();

    out.add(player.exportPlayer());
    out.add(new String[] {Integer.toString(turn), Integer.toString(maxLiar)});

    for (String[] row : map.export()){
      out.add(row);
    }

    for (Engimon e : engimonliar){
      out.add(e.exportEngimon());
    }

    a.write(out);
  }

  public void load(String filename) {
    GameFile filedata = new GameFile(filename, " ");
    List<String[]> file = filedata.read();
    this.engimonliar = new ArrayList<>();
    this.containerskill = new ArrayList<>();
    initSkills();

    player = new Player(file.get(0));
    turn = Integer.parseInt(file.get(1)[0]);
    maxLiar = Integer.parseInt(file.get(1)[1]);
    // sr mr ar
    if (file.get(1).length>2){
      sr = Integer.parseInt(file.get(1)[2]);
      mr = Integer.parseInt(file.get(1)[2]);
      ar = Integer.parseInt(file.get(1)[2]);
    }

    String x = file.get(2)[0], y = file.get(3)[0];
    List<String[]> loadmap = new ArrayList<>();
    int lastmap = 4+Integer.parseInt(y);

    loadmap.add(new String[] {x});
    loadmap.add(new String[] {y});
    int i;
    for (i = 4; i < lastmap; i++){
      loadmap.add(file.get(i));
    }

    map = new Map(loadmap);
    map.playerInisiasi(player);
    map.engimonInisiasi(player.getActiveEngimon());

    for (i = lastmap; i < file.size(); i++){
      Engimon e;
      String [] engi = file.get(i);
      String specs = engi[0];
      if (specs.equals("firemon")){
        e = new Firemon(engi);
      } else if (specs.equals("electricmon")){
        e = new Electricmon(engi);
      } else if (specs.equals("fireelectricmon")){
        e = new FireElectricmon(engi);
      } else if (specs.equals("groundmon")){
        e = new Groundmon(engi);
      } else if (specs.equals("icemon")){
        e = new Icemon(engi);
      } else if (specs.equals("watergroundmon")){
        e = new WaterGroundmon(engi);
      } else if (specs.equals("watericemon")){
        e = new WaterIcemon(engi);
      } else if (specs.equals("watermon")){
        e = new Watermon(engi);
      } else {
        e = new Engimon(engi);
      }
      engimonliar.add(e);
      map.spawnEngimonLiar(e);
    }

    window.updatetext("Welcome back, ");
    window.updatetext(player.getNamaPlayer());
  }
}