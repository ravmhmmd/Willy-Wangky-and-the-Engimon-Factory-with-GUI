

public interface InventoryItem {
    public String printNama();
    public String printInfo();
    public String getNama();
}
