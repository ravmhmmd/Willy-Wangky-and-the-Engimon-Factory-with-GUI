

public interface Interraction {
    public void interract();
}
